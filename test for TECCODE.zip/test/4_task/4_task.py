
# Создаем функцию сортировки
def sort(strings:list):
    sorted_min_to_max = sorted(strings, key=len, reverse=True)
    sorted_max_to_min = sorted(strings, key=len)
    return sorted_min_to_max, sorted_max_to_min

# Используем функцию
rezult = ["i", "love", "python", "mooooore", "than", "sleep"]
print("Rezult:", sort(rezult))

