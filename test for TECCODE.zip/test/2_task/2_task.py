
# 2 задание: создаем функцию
def numbers_in_range(min_number,max_number):
    numbers_between:list = []  # создаем пустой финальный список
    for i in range(min_number+1,max_number):  # создаем цикл где берем все числа в диапазоне
        numbers_between.append(i)  # добавляем числа в финальный список
    return numbers_between

# используем функцию
rezult=numbers_in_range(0,11)    
print(rezult)