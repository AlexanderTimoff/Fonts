      
# 1 задание: создаем функцию
def unique_numbers(numbers: list):
    unique_list = []  #создаем пустой финальный список
    for num in numbers:  # создаем цикл перебирая каждое число в первоначальном списке
        if num not in unique_list:  # если число уже добавлялось в финальный список оно не проходит условие 
            unique_list.append(num)  # добавляем в финальный список число прошедшее цикл
    return unique_list # возвращаем готовый список уникальных чисел

# используем функцию
digits = [1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, 7]
result = unique_numbers(digits)
print(result)
