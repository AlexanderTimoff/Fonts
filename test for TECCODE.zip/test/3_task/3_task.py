import math


class Point():
    def __init__(self,x,y):
        self.x=x
        self.y=y
        
    def initialization(self):
        return f"""
                Координаты Вашей точки равны: 
                x={self.x}
                y={self.y}
                """ 
    
    def distance_between(self,second_point):
        distance= math.sqrt((self.x - second_point.x)**2 + (self.y - second_point.y)**2)
        return f"Расстояние от нашей точки до точки номер два равно: {distance}"
    
    def change_coords(self,new_x,new_y):
        self.x=new_x
        self.y=new_y
        return f"""
                Новые коорддинаты установлены:
                x={self.x}
                y={self.y}
                """   
                
point_1=Point(455,225)
point_2=Point(415,205)

print(point_1.initialization())  
print(point_1.distance_between(point_2)) 
print(point_1.change_coords(500,200))             
                